package com.esgi.pa.api.error;

public record ErrorDto(Object errors) {
}
