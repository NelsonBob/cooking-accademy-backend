package com.esgi.pa.domain.enums;

public enum StatusMessageEnum {
    JOIN,
    MESSAGE
}