package com.esgi.pa.domain.enums;

/**
 * Enum représentant un rôle utilisateur
 */
public enum TypeEventEnum {
  Reservation,
  Meeting
}
