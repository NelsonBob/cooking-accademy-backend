package com.esgi.pa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CookingAccademyBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
